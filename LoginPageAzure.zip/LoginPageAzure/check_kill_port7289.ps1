$p = (Get-NetTCPConnection -LocalPort 7289 -ErrorAction SilentlyContinue).OwningProcess
if ($p) {
  Write-Host "PID: $p"
  Get-Process -Id $p | Format-Table Id,ProcessName
  Stop-Process -Id $p -Force
  Write-Host "Stopped process $p"
} else {
  Write-Host "No process on port 7289"
}
