namespace LoginDemo.Models
{
    public class DashboardViewModel
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? ObjectId { get; set; }
    }
}
