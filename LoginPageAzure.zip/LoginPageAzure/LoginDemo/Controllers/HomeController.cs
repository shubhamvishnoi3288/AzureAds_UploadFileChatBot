using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LoginDemo.Models;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace LoginDemo.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        ViewBag.UserPrincipalName =
            User.FindFirst("preferred_username")?.Value
            ?? User.FindFirst(ClaimTypes.Upn)?.Value;

        ViewBag.ObjectId =
            User.FindFirst("oid")?.Value;

        ViewBag.DisplayName =
            User.FindFirst("name")?.Value;
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [Authorize]
    public IActionResult Dashboard()
    {
        var name = User.FindFirst(ClaimTypes.Name)?.Value ?? User.Identity?.Name ?? "";
        var email = User.FindFirst("preferred_username")?.Value ?? User.FindFirst(ClaimTypes.Email)?.Value ?? "";
        var objectId = User.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier")?.Value ?? User.FindFirst("oid")?.Value ?? "";

        var model = new DashboardViewModel
        {
            Name = name,
            Email = email,
            ObjectId = objectId
        };

        return View(model);
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }


    
}
