using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using UglyToad.PdfPig;
using Azure;
using Azure.AI.DocumentIntelligence;
namespace LoginDemo.Controllers
{
    [Authorize]
    public class ChatController : Controller
    {
        private const string SessionBlobNameKey = "PdfBlobName";
        private readonly IConfiguration _config;
        private static readonly HttpClient _httpClient = new HttpClient();

        public ChatController(IConfiguration config)
        {
            _config = config;
        }

        [HttpGet]
        public IActionResult Upload()
        {
            return View();
        }

        // ==========================
        // PDF UPLOAD
        // ==========================
        [HttpPost]
        [RequestSizeLimit(100_000_000)]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                ViewBag.Message = "Please select a PDF file.";
                return View();
            }

            if (!Path.GetExtension(file.FileName).Equals(".pdf", StringComparison.OrdinalIgnoreCase))
            {
                ViewBag.Message = "Only PDF files are allowed.";
                return View();
            }

            var conn = _config["AzureBlob:ConnectionString"];
            var containerName = _config["AzureBlob:ContainerName"];

            var service = new BlobServiceClient(conn);
            var container = service.GetBlobContainerClient(containerName);
            await container.CreateIfNotExistsAsync();

            var blobName = $"{Guid.NewGuid()}_{file.FileName}";
            var blob = container.GetBlobClient(blobName);

            using var stream = file.OpenReadStream();
            await blob.UploadAsync(stream, overwrite: true);

            // ✅ store blob name in session
            HttpContext.Session.SetString(SessionBlobNameKey, blobName);

            ViewBag.Message = "PDF uploaded to Blob Storage. Ask a question below.";
            return View();
        }

        // ==========================
        // ASK QUESTION
        // ==========================
        //[HttpPost]
        //public async Task<IActionResult> Ask(string question)
        //{
        //    if (string.IsNullOrWhiteSpace(question))
        //        return Json(new { success = false, answer = "Please enter a question." });

        //    var blobName = HttpContext.Session.GetString(SessionBlobNameKey);
        //    if (string.IsNullOrEmpty(blobName))
        //        return Json(new { success = false, answer = "Please upload a PDF first." });

        //    var conn = _config["AzureBlob:ConnectionString"];
        //    var containerName = _config["AzureBlob:ContainerName"];

        //    var service = new BlobServiceClient(conn);
        //    var container = service.GetBlobContainerClient(containerName);
        //    var blob = container.GetBlobClient(blobName);

        //    if (!await blob.ExistsAsync())
        //        return Json(new { success = false, answer = "Uploaded PDF not found." });

        //    // --------------------------
        //    // Extract PDF text
        //    // --------------------------
        //    string pdfText;
        //    using (var ms = new MemoryStream())
        //    {
        //        await blob.DownloadToAsync(ms);
        //        ms.Position = 0;
        //        using var pdf = PdfDocument.Open(ms);
        //        pdfText = string.Join("\n", pdf.GetPages().Select(p => p.Text));
        //    }

        //    if (pdfText.Length > 30000)
        //        pdfText = pdfText[..30000] + "\n...[truncated]";

        //    // --------------------------
        //    // Azure OpenAI
        //    // --------------------------
        //    var endpoint = _config["AzureOpenAI:Endpoint"]!.TrimEnd('/');
        //    var apiKey = _config["AzureOpenAI:ApiKey"];
        //    var deployment = _config["AzureOpenAI:DeploymentName"];

        //    var payload = new
        //    {
        //        messages = new[]
        //        {
        //            new { role = "system", content = "Answer strictly from the provided document." },
        //            new { role = "user", content = $"DOCUMENT:\n{pdfText}\n\nQUESTION:\n{question}" }
        //        },
        //        temperature = 0.0,
        //        max_tokens = 512
        //    };

        //    var request = new HttpRequestMessage(
        //        HttpMethod.Post,
        //        $"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version=2024-11-01-preview");

        //    request.Headers.Add("api-key", apiKey);
        //    request.Content = new StringContent(
        //        JsonSerializer.Serialize(payload),
        //        Encoding.UTF8,
        //        "application/json");

        //    var response = await _httpClient.SendAsync(request);
        //    var json = await response.Content.ReadAsStringAsync();

        //    if (!response.IsSuccessStatusCode)
        //        return Json(new { success = false, answer = json });

        //    using var doc = JsonDocument.Parse(json);
        //    var answer = doc.RootElement
        //        .GetProperty("choices")[0]
        //        .GetProperty("message")
        //        .GetProperty("content")
        //        .GetString();

        //    return Json(new
        //    {
        //        success = true,
        //        answer = answer ?? "No answer found in the document."
        //    });
        //}

        // ==========================
        // ASK QUESTION
        // ==========================
        [HttpPost]
        public async Task<IActionResult> Ask(string question)
        {
            // --------------------------
            // 1. Validate input
            // --------------------------
            if (string.IsNullOrWhiteSpace(question))
            {
                return Json(new { success = false, answer = "Please enter a question." });
            }

            var blobName = HttpContext.Session.GetString(SessionBlobNameKey);
            if (string.IsNullOrEmpty(blobName))
            {
                return Json(new { success = false, answer = "Please upload a PDF first." });
            }

            // --------------------------
            // 2. Blob config
            // --------------------------
            var blobConn = _config["AzureBlob:ConnectionString"];
            var containerName = _config["AzureBlob:ContainerName"];

            if (string.IsNullOrWhiteSpace(blobConn) || string.IsNullOrWhiteSpace(containerName))
            {
                return Json(new { success = false, answer = "Azure Blob Storage is not configured." });
            }

            var blobService = new BlobServiceClient(blobConn);
            var container = blobService.GetBlobContainerClient(containerName);
            var blob = container.GetBlobClient(blobName);

            if (!await blob.ExistsAsync())
            {
                return Json(new { success = false, answer = "Uploaded PDF not found." });
            }

            // --------------------------
            // 3. Download PDF
            // --------------------------
            using var pdfStream = new MemoryStream();
            await blob.DownloadToAsync(pdfStream);
            pdfStream.Position = 0;

            if (pdfStream.Length < 100)
            {
                return Json(new { success = false, answer = "Invalid or empty PDF file." });
            }

            // --------------------------
            // 4. OCR via Azure Document Intelligence (FIXED)
            // --------------------------
            var docEndpoint = _config["AzureOpenAI:AzureDocumentEndpoint"];
            var docKey = _config["AzureOpenAI:AzureDocumentKey"];

            if (string.IsNullOrWhiteSpace(docEndpoint) || string.IsNullOrWhiteSpace(docKey))
            {
                return Json(new { success = false, answer = "Azure Document Intelligence is not configured." });
            }

            var docClient = new DocumentIntelligenceClient(
                new Uri(docEndpoint),
                new AzureKeyCredential(docKey));

            // 🔥 FIX: Convert Stream → BinaryData
            var binaryData = BinaryData.FromStream(pdfStream);

            var operation = await docClient.AnalyzeDocumentAsync(
                WaitUntil.Completed,
                "prebuilt-read",
                binaryData);

            var result = operation.Value;

            var sb = new StringBuilder();
            foreach (var page in result.Pages)
            {
                foreach (var line in page.Lines)
                {
                    sb.AppendLine(line.Content);
                }
            }

            var documentText = sb.ToString();

            if (string.IsNullOrWhiteSpace(documentText))
            {
                return Json(new
                {
                    success = false,
                    answer = "No readable text found in the PDF. The PDF may be scanned or image-based."
                });
            }

            if (documentText.Length > 30000)
            {
                documentText = documentText.Substring(0, 30000) + "\n...[truncated]";
            }

            // --------------------------
            // 5. Azure OpenAI
            // --------------------------
            var endpoint = _config["AzureOpenAI:Endpoint"]?.TrimEnd('/');
            var apiKey = _config["AzureOpenAI:ApiKey"];
            var deployment = _config["AzureOpenAI:DeploymentName"];

            if (string.IsNullOrWhiteSpace(endpoint) ||
                string.IsNullOrWhiteSpace(apiKey) ||
                string.IsNullOrWhiteSpace(deployment))
            {
                return Json(new { success = false, answer = "Azure OpenAI is not configured properly." });
            }

            var payload = new
            {
                messages = new[]
                {
            new
            {
                role = "system",
                content = "Answer strictly from the provided document. If the answer is not present, say you do not know."
            },
            new
            {
                role = "user",
                content = $"DOCUMENT:\n{documentText}\n\nQUESTION:\n{question}"
            }
        },
                temperature = 0.0,
                max_tokens = 512
            };

            var request = new HttpRequestMessage(
                HttpMethod.Post,
                $"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version=2024-11-01-preview");

            request.Headers.Add("api-key", apiKey);
            request.Content = new StringContent(
                JsonSerializer.Serialize(payload),
                Encoding.UTF8,
                "application/json");

            var response = await _httpClient.SendAsync(request);
            var json = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                return Json(new { success = false, answer = json });
            }

            using var doc = JsonDocument.Parse(json);
            var answer = doc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString();

            return Json(new
            {
                success = true,
                answer = string.IsNullOrWhiteSpace(answer)
                    ? "No answer found in the document."
                    : answer
            });
        }


    }
}
